import React from 'react'
import './Skills.css'
function Skills() {
    return (
        <div>
            <ol>
                <li>Html</li>
                <li>css</li>
                <li>javascript</li>
            </ol>
        </div>
    )
}

export default Skills
