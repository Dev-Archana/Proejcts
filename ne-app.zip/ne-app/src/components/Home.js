import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'

function Home() {
    return (
        <div>
            <Navbar />
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Atque possimus necessitatibus, est illum voluptatum
                doloremque facere accusantium autem voluptatibus, dolore consequuntur pariatur unde id. Saepe nostrum cumque
                voluptatum perspiciatis blanditiis.</p> <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Atque possimus necessitatibus, est illum voluptatum
                    doloremque facere accusantium autem voluptatibus, dolore consequuntur pariatur unde id. Saepe nostrum cumque
                    voluptatum perspiciatis blanditiis.</p> <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Atque possimus necessitatibus, est illum voluptatum
                        doloremque facere accusantium autem voluptatibus, dolore consequuntur pariatur unde id. Saepe nostrum cumque
                        voluptatum perspiciatis blanditiis.</p> <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Atque possimus necessitatibus, est illum voluptatum
                            doloremque facere accusantium autem voluptatibus, dolore consequuntur pariatur unde id. Saepe nostrum cumque
                            voluptatum perspiciatis blanditiis.</p> <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Atque possimus necessitatibus, est illum voluptatum
                                doloremque facere accusantium autem voluptatibus, dolore consequuntur pariatur unde id. Saepe nostrum cumque
                                voluptatum perspiciatis blanditiis.</p>
            <Footer />
        </div>
    )
}

export default Home
